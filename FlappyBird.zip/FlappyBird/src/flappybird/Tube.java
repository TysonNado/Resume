/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybird;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Tyson
 */
public class Tube extends Rectangle {

    public ArrayList<Tube> Tubes() {
        int TUBE_SPACING = 114;
        Random rand = new  Random();
        ArrayList<Tube> Tubes = new ArrayList<Tube>();
        Tube topTube = new Tube();
        Tube bottomTube = new Tube();

        topTube.height = rand.nextInt(FlappyBird.HEI / 2);
        topTube.y = 0;
        topTube.width = 50;
        topTube.x = FlappyBird.WID;

        bottomTube.y = topTube.height + TUBE_SPACING;
        bottomTube.height = FlappyBird.HEI - (topTube.height + TUBE_SPACING);
        bottomTube.width = 50;
        bottomTube.x = FlappyBird.WID;

        Tubes.add(topTube);
        Tubes.add(bottomTube);

        return Tubes;

    }

}
