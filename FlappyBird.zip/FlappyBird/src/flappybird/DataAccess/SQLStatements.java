/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybird.DataAccess;

import flappybird.FlappyBird;
import flappybird.User;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;


/**
 * @ Project
 * @Date 2018-12-27
 * @Author Tyson
 */
public class SQLStatements {

    public static User player = new User(null, null, 0);
    static String mySQLDriver = "com.mysql.jdbc.Driver";
    static String mySQLUrl = "jdbc:mysql://localhost/adventureworks?verifyServerCertificate=false&useSSL=false";
    static String userName = "dev";
    static String password = "dev1234";

    public static User Login(String user, String pass) {

        try {
            Class.forName(mySQLDriver).newInstance();
            Connection conn = DriverManager.getConnection(mySQLUrl, userName, password);
            Statement stmnt = conn.createStatement();

            String sqlSt1 = "Select * from User where username = " + user + " and password = " + pass;
            stmnt.executeQuery(sqlSt1);
            ResultSet rs = stmnt.getResultSet();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            while (rs.next()) {
                player = new User(rs.getString(1), rs.getString(2), rs.getInt(3));
            }
            player.isLoggedIn = true;

            rs.close();
            conn.close();

            return player;

        } catch (SQLException e) {
            p(e.getMessage());
            player.isLoggedIn = false;
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e) {
            //Do logging
        }
    }

    public static void updateHighScore() {

        try {
            Class.forName(mySQLDriver).newInstance();
            try (Connection conn = DriverManager.getConnection(mySQLUrl, userName, password)) {
                String sql = "UPDATE User  SET Highscore = " + FlappyBird.score;
                try (Statement stmnt = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE)) {
                    int recordCount = stmnt.executeUpdate(sql);
                    p("Updated rows: " + recordCount);
                } catch (SQLException e) {
                    p(e.getMessage());
                }
            }
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException e) {
            //Do logging
        }
    }

    /**
     * Console printer
     *
     * @param msg
     */
    static void p(String msg) {
        System.out.println(msg);
    }
}
