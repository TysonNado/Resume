/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybird;

import static flappybird.FlappyBird.room;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import sun.applet.Main;

public class Bird extends Rectangle {

    private int spd = 4;
    public int pressed = 0;
    private BufferedImage[] texture;
    private BufferedImage Sheet;
    private ArrayList<Tube> tubes;
    private int imageindex = 0;
    private boolean isFalling = false;
    private int frames;

    public Bird(int x, int y, ArrayList<Tube> tubes) throws IOException {
        setBounds(x, y, 32, 32);
        texture = new BufferedImage[3];
        this.tubes = tubes;
        try {
            Sheet = ImageIO.read(getClass().getClassLoader().getResource("res/SpritesSheet.png"));

            texture[0] = Sheet.getSubimage(0, 0, 16, 16);
            texture[1] = Sheet.getSubimage(16, 0, 16, 16);
            texture[2] = Sheet.getSubimage(32, 0, 16, 16);
        } catch (IOException e) {
        }
    }

    public void Update() {
        isFalling = false;
        switch (pressed) {
            case 1:
                y = y - 4;
                imageindex = 2;
                frames = 0;
                break;
            case 2:
                y = y + 4;
                isFalling = true;
                frames++;
                imageindex = 1;
                if (frames > 15) {
                    frames = 15;
                }
                break;
            default:
                spd = 4;
                imageindex = 0;
                break;
        }

        if (isFalling) {
            if (isFalling && frames >= 15) {
                imageindex = 0;
            }
        }


        for (int i = 0; i < this.tubes.size(); i++) {
            if (this.intersects(tubes.get(i)) || y >= FlappyBird.HEI || y <= 0) {
                FlappyBird.STATE = FlappyBird.PAUSE_SCREEN;
                FlappyBird.room = new Room(80);
                tubes = FlappyBird.room.tubes;
                y = FlappyBird.HEI / 2;
              
                break;
            }
        }
    }

    public void Render(Graphics g) {
        //     g.setColor(Color.red);
        //   g.fillOval(x, y, width, height);
        g.drawImage(texture[imageindex], x, y, width, height, null);
    }
}
