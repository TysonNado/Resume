/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybird;

import flappybird.DataAccess.SQLStatements;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author Tyson
 */
public class FlappyBird extends Canvas implements Runnable, KeyListener {

    public static final int WID = 700;
    public static final int HEI = 500;
    private boolean running = false;
    private Thread thread;
    public static Room room;
    public Bird bird;
    public static double score = 0;
    public static final int PAUSE_SCREEN = 0, GAME = 1;
    public static int STATE = -1;

    public FlappyBird() {

        try {
            Dimension d = new Dimension(FlappyBird.WID, FlappyBird.HEI);
            setSize(d);
            addKeyListener(this);
            STATE = PAUSE_SCREEN;
            room = new Room(110);
            bird = new Bird(20, FlappyBird.HEI / 2, room.tubes);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public synchronized void start() {
        if (running) {
            return;
        }
        running = true;
        thread = new Thread(this);
        thread.start();
    }

    public synchronized void stop() throws InterruptedException {
        if (!running) {
            return;
        }
        running = false;
        thread.join();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("flappy Bird");
        FlappyBird flappyBird = new FlappyBird();
        frame.add(flappyBird);
        frame.setResizable(false);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        flappyBird.start();
    }

    @Override
    public void run() {
        double timer = System.currentTimeMillis();
        int fps = 0;
        long lasttime = System.nanoTime();
        double delta = 0;
        double ms = 1000000000 / 60;

        while (running) {
            long now = System.nanoTime();
            delta += (now - lasttime) / ms;
            lasttime = now;

            while (delta >= 1) {
                update();
                render();
                fps++;
                delta--;
            }
            if (System.currentTimeMillis() - timer >= 1000) {
                fps = 0;
                timer += 1000;
            }

        }

        try {
            stop();

        } catch (InterruptedException ex) {
            Logger.getLogger(FlappyBird.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void update() {
        if (STATE == GAME) {
            room.update();
            bird.Update();
        }
    }

    private void render() {
        BufferStrategy bs = getBufferStrategy();
        if (bs == null) {
            createBufferStrategy(3);
            return;
        }

        Graphics g = bs.getDrawGraphics();
        g.setColor(Color.CYAN);
        g.fillRect(0, 0, FlappyBird.WID, FlappyBird.HEI);

        if (STATE == GAME) {
            room.Render(g);
            bird.Render(g);
        } else if (STATE == PAUSE_SCREEN) {
            int boxwid = 215;
            int boxhei = 70;
            int xx = FlappyBird.WID / 2 - boxwid / 2;
            int yy = FlappyBird.HEI / 2 - boxhei / 2;
            g.setColor(Color.DARK_GRAY);
            g.fill3DRect(xx, yy, boxwid, boxhei, running);

            g.setColor(Color.WHITE);
            g.setFont(new Font(Font.DIALOG, Font.BOLD, 16));
            g.drawString("Press *P to Play", xx + 5, yy + 20);
            g.drawString("Press *E to Exit", xx + 5, yy + 40);

            if (score > 0) {
                g.drawString("Your Score is: " + (int) score, xx + 5, yy + 60);

                g.setColor(Color.BLACK);
                g.setFont(new Font(Font.DIALOG, Font.BOLD,32));
                g.drawString("GAME OVER", xx + 5, yy + 5);
            }
            if (SQLStatements.player.isLoggedIn == true) {
                if (score > SQLStatements.player.Highscore) {
                    g.drawString("New Highscore!", xx , yy + 80);
                    SQLStatements.updateHighScore();
                }

            }
        }

        g.setColor(Color.WHITE);

        g.setFont(
                new Font(Font.DIALOG, Font.BOLD, 20));
        g.drawString(
                "Score: " + (int) score,
                10, 20);
        g.dispose();

        bs.show();
    }

    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {

        if (STATE == GAME) {

            if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                bird.pressed = 1;
            }
        } else if (STATE == PAUSE_SCREEN) {
            if (e.getKeyCode() == KeyEvent.VK_P) {
                FlappyBird.score = 0;
                STATE = GAME;
            } else if (e.getKeyCode() == KeyEvent.VK_E) {
                System.exit(0);
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            bird.pressed = 2;
        }
    }

}
