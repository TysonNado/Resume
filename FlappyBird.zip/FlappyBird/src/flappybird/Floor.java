/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybird;

import java.awt.Rectangle;

/**
 *
 * @author Tyson
 */
public class Floor extends Rectangle {

    public Rectangle Floor() {
    }
}
