/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybird;

/**
 *
 * @author Tyson
 */
public class User {
    public String username;
    public  String password;
    public int Highscore;
    public boolean isLoggedIn = false;

    public User(String username, String password, int Highscore) {
        this.username = username;
        this.password = password;
        this.Highscore = Highscore;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getHighscore() {
        return Highscore;
    }

    public void setHighscore(int Highscore) {
        this.Highscore = Highscore;
    }
    
}
