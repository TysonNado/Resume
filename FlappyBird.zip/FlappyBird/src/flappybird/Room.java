/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybird;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.ArrayList;
/**
 *
 * @author Tyson
 */
public class Room {

    public ArrayList<Tube> tubes;
    private final int time;
    private int currentTime;
    private final int speed = 4;
    private Rectangle floor;

    public Room(int time) {
        tubes = new ArrayList<>();
        this.time = time;
    }



    public void update() {
        currentTime++;

        if (currentTime == time) {
            currentTime = 0;

            Tube tube = new Tube();

            tube.Tubes().forEach((t) -> {
                tubes.add(t);
            });
        }
        for (int i = 0; i < tubes.size(); i++) {
            Rectangle rectangle = tubes.get(i);
            rectangle.x -= speed;
            
            if (rectangle.x + rectangle.width <= 0) {
                tubes.remove(i--);
                FlappyBird.score = FlappyBird.score + 0.5;
                //   continue;
            }
        }

    }

    public void Render(Graphics g) {
        g.setColor(Color.GREEN);

        for (int i = 0; i < tubes.size(); i++) {
            Rectangle rectangle = tubes.get(i);
            g.fill3DRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height, true);

        }
    }

}
